object Form1: TForm1
  Left = 752
  Top = 260
  BorderIcons = [biSystemMenu, biMinimize]
  BorderStyle = bsSingle
  Caption = 'unarc.dll test'
  ClientHeight = 458
  ClientWidth = 497
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -14
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poScreenCenter
  OnClose = FormClose
  OnDestroy = FormDestroy
  OnShow = FormShow
  PixelsPerInch = 120
  TextHeight = 17
  object Label1: TLabel
    Left = 10
    Top = 21
    Width = 144
    Height = 17
    Caption = #1040#1088#1093#1080#1074' '#1076#1083#1103' '#1088#1072#1089#1087#1072#1082#1086#1074#1082#1080
  end
  object Label2: TLabel
    Left = 10
    Top = 81
    Width = 137
    Height = 17
    Caption = #1055#1091#1090#1100' '#1076#1083#1103' '#1088#1072#1089#1087#1072#1082#1086#1074#1082#1080
  end
  object Label3: TLabel
    Left = 157
    Top = 199
    Width = 200
    Height = 17
    AutoSize = False
  end
  object Label4: TLabel
    Left = 230
    Top = 180
    Width = 51
    Height = 17
    Alignment = taCenter
    AutoSize = False
    Transparent = False
  end
  object pb: TProgressBar
    Left = 10
    Top = 157
    Width = 473
    Height = 22
    Max = 1000
    Smooth = True
    TabOrder = 3
  end
  object Button1: TButton
    Left = 10
    Top = 187
    Width = 117
    Height = 33
    Caption = #1056#1072#1089#1087#1072#1082#1086#1074#1072#1090#1100
    TabOrder = 0
    OnClick = Button1Click
  end
  object Memo1: TMemo
    Left = 10
    Top = 241
    Width = 473
    Height = 208
    Lines.Strings = (
      #1048#1085#1092#1086)
    ReadOnly = True
    ScrollBars = ssBoth
    TabOrder = 1
    WordWrap = False
  end
  object Button2: TButton
    Left = 388
    Top = 187
    Width = 98
    Height = 33
    Caption = #1054#1090#1084#1077#1085#1072
    TabOrder = 2
    OnClick = Button2Click
  end
  object Edit1: TEdit
    Left = 10
    Top = 46
    Width = 420
    Height = 21
    TabOrder = 4
    Text = 'olly.arc'
  end
  object Edit2: TEdit
    Left = 10
    Top = 106
    Width = 420
    Height = 21
    TabOrder = 5
    Text = 'freearctest\'
  end
  object Button4: TButton
    Left = 438
    Top = 46
    Width = 45
    Height = 27
    Caption = '...'
    TabOrder = 6
    OnClick = Button4Click
  end
  object Button5: TButton
    Left = 438
    Top = 106
    Width = 45
    Height = 27
    Caption = '...'
    TabOrder = 7
    OnClick = Button5Click
  end
  object OpenDialog1: TOpenDialog
    DefaultExt = '.arc'
    Filter = #1040#1088#1093#1080#1074#1099' FreeArc|*.arc|'#1042#1089#1077' '#1092#1072#1081#1083#1099'|*.*'
    Left = 184
    Top = 8
  end
end
