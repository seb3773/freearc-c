Download example of using unarc.dll with Autoplay Media Studio at http://freearc.org/download/AMS/
