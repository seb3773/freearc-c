﻿// Written by Mohammad Khalifa, me(a______t)smart-arab.com

using System;
using System.Runtime.InteropServices;

class UnarcDllExample
{
    [DllImport("unarc.dll")]
    public static extern int FreeArcExtract(cbtype callback, string cmd1, string cmd2, string cmd3, string cmd4, string cmd5, string cmd6, string cmd7, string cmd8, string cmd9, string cmd10, string cmd11, string cmd12, string cmd13, string cmd14, string cmd15, string cmd16, string cmd17, string cmd18, string cmd19, string cmd20);

    [DllImport("unarc.dll")]
    public static extern void UnloadDLL();

    public delegate int cbtype(string what, int int1, int int2, string str);

    static int callbackfunction(string what, int int1, int int2, string str)
    {
        if (what.Equals("password?"))
        {
            Console.WriteLine("Enter password:");
            str = Console.ReadLine();
        }

        Console.WriteLine("callback(\"{0}\",{1}, {2}, \"{3}\")", what, int1, int2, str);

        if (what.Equals("password?"))
            return 'y';
        else if (what.Equals("overwrite?"))
            return 'y';
        else
            return 1;
    }

    static int Main(string[] argc)
    {

        if (argc.Length <= 2)
        {
            Console.WriteLine("Usage: UnarcDllExample.exe [l|e|x|t] [options] [--] archive [files]");
            return 1;
        }
        string[] command = new string[20];

        for (int i = 0; i < 19; i++)
        {
            if (i >= argc.Length)
                command[i] = string.Empty;
            else
                command[i] = argc[i];
        }

        int result;

        // Command to execute.
        // NULL-terminated UTF8-encoded strings.
        // Every option/filename should be a separate string.
        // Started with command to execute and options, then "--", then archive name and filenames.
        // Execute command using callback() to interact with user. Return value is 0 for success, error code otherwise
        cbtype callback = new cbtype(callbackfunction);
        result = FreeArcExtract(callback, command[0], command[1], command[2], command[3], command[4], command[5], command[6], command[7], command[8], command[9],
            command[10], command[11], command[12], command[13], command[14], command[15], command[16], command[17], command[18], command[19]);


        if (result > 0)
        {
            Console.WriteLine("FreeArcExtract() failed with return code {0}\n", result);
            return 1;
        }

        UnloadDLL();
        return 0;
    }
}

