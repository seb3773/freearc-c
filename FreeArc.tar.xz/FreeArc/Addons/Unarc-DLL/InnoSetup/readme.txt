Installers written using InnoSetup can use unarc.dll for extraction of
FreeArc archives. There are few third-party projects implementing this,
including ISDone and ISFreeArcExtract
( http://www.krinkels.ru/forum/forumdisplay.php?f=18 )

More info and latest versions can be found at http://freearc.org/InnoSetup.aspx