64-bit LZMA implementation improves speed by 10-20% and allows LZMA to use more than 4 GBytes of memory.

But special FreeArc-LZMA-x64.exe now is outdated and replaced by the more universal FAZip package, which latest version is available at http://freearc.org/download/research/

At the moment of this FreeArc version release, the latest and compatible with FreeArc version of FAZip was http://freearc.org/download/research/fazip03.zip
